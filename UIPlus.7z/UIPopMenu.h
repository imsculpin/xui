#pragma once
#include <map>
#include "CPTDC.h"
#include "UIPlus.h"
#include <vector>
#include "UIType.h"
using std::vector;
using std::map;
class CUIPopMenu
{
public:
	CUIPopMenu();
	~CUIPopMenu();
	UINT TrackPopupMenu( MENUDATA* pMenuData, int nCount, int x, int y, int fuFlags, ACCEL* pAccels = NULL, int nAccelCount = 0 );

protected:
	BOOL CreateMenu( HWND hWndParent = NULL  );
	static LRESULT WINAPI WinProcess( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam );
	virtual LRESULT WinProc( UINT message, WPARAM wParam, LPARAM lParam );
	void DrawMenu( HDC hDC, LPCRECT lpRectClip = NULL );
	void EndMenu();
	static CUIPopMenu* FromHandle( HWND hWnd )
	{
		CUIPopMenu* pWin = NULL;
		if ( m_mapWindows.size() )
		{
			map<HWND, CUIPopMenu*>::iterator _itFound = m_mapWindows.find( hWnd );
			if( _itFound != m_mapWindows.end() )
			{
				return _itFound->second;
			}
		}
		return NULL;
	}

	bool IsSubMenuGetFocus( HWND hFocus )
	{
		if ( m_subMenu )
		{
			if ( m_subMenu->m_hWnd == hFocus )
			{
				return true;
			}
			return m_subMenu->IsSubMenuGetFocus( hFocus );
		}
		return false;
	}

	//ˢ��ָ������
	void InvalidRect( LPRECT lpRect );
	//������
	void DrawBkGnd( HDC hdc );
	

private:
	vector<RECT> m_itemsRect;
	UINT  m_nCmdRet;
	HWND  m_hWnd;
	CPTDC m_bufferDC;
	HBITMAP m_hBufferBmp;
	HBITMAP m_hOldBufferBmp;
	CPTDC   m_bkGndDC;
	HBITMAP m_hbkBitmap;
	HBITMAP m_hbkOldBitmap;
	BOOL	m_bPoping;
	MENUDATA*   m_pMenuData;
	int			m_nMenuCount;
	ACCEL*		m_pAccel;
	int			m_nAccelCount;
	int			m_fuFlags;
	int         m_nMouseIn;
	int         m_nLbDown;
	int			m_topOffset;
	CUIPopMenu* m_subMenu;
	CUIPopMenu* m_parentMenu;
	static	 map<HWND, CUIPopMenu*> m_mapWindows;
public:
	static	 IMG*    m_pBkGnd;
	static   IMG*    m_pBkItem;  //�˵�����꾭��ʱ�ı���
	static   IMG*	 m_pSeparator; //�ָ���ͼ��
	static   Margin  m_margin;
	static   bool    m_bLayered;
	static   IImage* m_pSubArrow;//�Ӳ˵���ʶͼ��
	static   UINT	 m_uItemHeight;//�˵��߶�
	static   UINT    m_uIconWidth; //�˵������ͼ�����
	static   UINT    m_uDrawMask;  //�˵���������� ��MENUDRAWMASK
	static   UINT    m_uAlpha;     //�˵�͸����
	static   HFONT   m_font;
};
