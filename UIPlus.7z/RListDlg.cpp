// RListDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "RList.h"
#include "RListDlg.h"
#include <GdiPlus.h>
#include ".\rlistdlg.h"
#include "strfun.h"
using namespace Gdiplus;
#pragma comment( lib, "gdiplus.lib" )

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

enum MSGID
{
	ID_TREE = 1000,
	ID_LIST,
	ID_VLLIST,
	ID_HEAD,
	ID_NAME,
	ID_MINI,
	ID_MAX,
	ID_CLOSE,
	ID_AUTOLIST,
	ID_SKIN,
	IDC_ATC_CHECKBOX,
	IDC_ALPHA,
	IDC_SHOWTAB,
};

// CRListDlg �Ի���
HFONT CRListDlg::m_normalFont;
HIMAGE	  CRListDlg::m_RLBmpArray[CRListDlg::BMP_END];
CRListDlg::CRListDlg()
{
}

CRListDlg::~CRListDlg()
{
// 	for ( int _i = 0; _i < BMP_END; ++_i )
// 	{
// 		m_RLBmpArray[_i] = NULL;
// 	}
	m_tray.Destroy();
}

// CRListDlg ��Ϣ��������

BOOL CRListDlg::OnInitWnd()
{
	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	//SetAlpha( 0 );
	tstring strImagePath = _T(".\\image\\");
	RECT rcClient;
	RECT_EMPTY( rcClient );
	m_tab.Create(  rcClient, this, 1010 );
	m_list.Create(  rcClient, this, 1005 );
	m_list.EnableScroll( VERT, true );
	m_vlist.Create(  rcClient, this, 1006 );
	m_vlist.EnableScroll( VERT, true );
	m_autolist.Create(  rcClient, this, 1007 );
	m_autolist.EnableScroll( VERT, true );
	m_head.Create(  rcClient, this, 1008 );
	m_tree.Create( rcClient, this, 1009 );
	m_tree.EnableScroll( VERT, true );
	m_tree.EnableDbClickExpand( false );
	m_tree.ScrollBarInClient( true );
	
	//m_tree.SetIndentationX( 10 );
	LOGFONT lgFont;
	memset(&lgFont, 0, sizeof(LOGFONT));
	lgFont.lfHeight = -12;
	lstrcpy(lgFont.lfFaceName, _T("Arial"));
	lgFont.lfOutPrecision = OUT_TT_PRECIS;
	lgFont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
	lgFont.lfQuality = PROOF_QUALITY;
	lgFont.lfQuality = ANTIALIASED_QUALITY;
	lgFont.lfPitchAndFamily = FF_SWISS | VARIABLE_PITCH;
	lgFont.lfWeight = FW_NORMAL;
	m_normalFont = CreateFontIndirect( &lgFont );

	_LoadImages();
	Margin margin;
	margin.left = 3;
	margin.right = 3;
	margin.top = 3;
	margin.bottom =3;
	CUIButton null;
	null.Create( _T(""), RECT_C(0,0,0,0) );
	CUIImage  nullImag;
	nullImag.Create( _T(""), RECT_C(0,0,0,0) );
	nullImag.SetBkColor( X_TRANSPARENT );
	CUIButton thumb;
	HIMAGE hNormal = CreateImage( strImagePath + _T("1.png") );
	ImageInfo info1 = {0};
	hNormal->GetImageInfo( &info1 );
	thumb.Create( _T(""), RECT_C(0,0, 20, 20) );
	thumb.SetNormalImage( CreateImage( strImagePath + _T("2.png")) );
	thumb.SetMargin( margin );
	CUIScroll* pScroll = m_tree.GetScrollBar( VERT );
	if ( pScroll )
	{
		pScroll->SetScroll( null, null, nullImag, thumb );
	}
	 pScroll = m_list.GetScrollBar( VERT );
	if ( pScroll )
	{
		pScroll->SetScroll( null, null, nullImag, thumb );
	}
	 pScroll = m_vlist.GetScrollBar( VERT );
	if ( pScroll )
	{
		pScroll->SetScroll( null, null, nullImag, thumb );
	}
	 pScroll = m_autolist.GetScrollBar( VERT );
	if ( pScroll )
	{
		pScroll->SetScroll( null, null, nullImag, thumb );
	}
	if ( m_RLBmpArray[BMP_ROWHOT] )
	{
		m_tree.SetHotNodeBkGnd( m_RLBmpArray[BMP_ROWHOT], &margin );
		m_vlist.SetHotRowBkGnd( m_RLBmpArray[BMP_ROWHOT], &margin );
		m_list.SetHotRowBkGnd( m_RLBmpArray[BMP_ROWHOT], &margin );
	}
	if ( m_RLBmpArray[BMP_ROWSEL] )
	{
		m_tree.SetSelectNodeBkGnd( m_RLBmpArray[BMP_ROWSEL],&margin );
		m_vlist.SetSelectRowBkGnd( m_RLBmpArray[BMP_ROWSEL], &margin );
		m_list.SetSelectRowBkGnd( m_RLBmpArray[BMP_ROWSEL], &margin );
	}
	m_list.SetLineSpace( 0 ) ;
	m_list.SetScrollStep( 80 );
	m_list.SetRowHeight( 48 );

	m_vlist.SetLineSpace( 0 );
	m_vlist.SetScrollStep( 80 );
	m_vlist.SetRowHeight( 48 );
	m_vlist.SetVirtualMode( &m_dbase, CRListDlg::_TranslateFromReocord );
	
	m_autolist.SetLineSpace( 0 );
	m_autolist.SetScrollStep( 80 );
	HIMAGE hBk = CreateImage( XT2W(strImagePath + _T("bkwnd.png")) );
	//COLORREF hBk = RGB( 128,128,128 );
// 	m_tree.SetBkGnd(hBk );
// 	m_list.SetBkGnd( hBk);
// 	m_autolist.SetBkGnd( hBk);
// 	m_vlist.SetBkGnd( hBk);
// 	m_tab.SetBkGnd( hBk);
 	m_tree.SetBkGnd( Color( 150, 255,255,255 ).GetValue() );
 	m_list.SetBkGnd( Color( 150, 255,255,255 ).GetValue() );
 	m_autolist.SetBkGnd( Color( 150, 255,255,255 ).GetValue() );
    m_vlist.SetBkGnd( Color( 150, 255,255,255 ).GetValue() );
    m_tab.SetBkGnd( Color( 150, 255,255,255 ).GetValue() );
	margin.top = 2;
	margin.bottom = 2;
	m_list.SetMargin( margin );
	m_tree.SetMargin( margin );
	hBk = CreateImage( XT2W(strImagePath + _T("bk.png")) );
	ImageInfo imageInfo = {0};
	hBk->GetImageInfo(&imageInfo);
	SetBkGnd( hBk, RECT_C( -50, -50, imageInfo.Width, imageInfo.Height ) );
	InitHead();
	Initlist();
	InitTree();
	m_head.HookNotify( CRListDlg::XMessageReciever, (DWORD)(DWORD_PTR)this );
	m_tree.HookNotify( CRListDlg::XMessageReciever, (DWORD)(DWORD_PTR)this );
	m_tab.HookNotify( CRListDlg::XMessageReciever, (DWORD)(DWORD_PTR)this );
	HIMAGE image = CreateImage( XT2W( _T(".\\image\\head.png")) );
	if ( image )
	{
		SetIcon( image->GetIcon(), TRUE );
		SetIcon( image->GetIcon(), FALSE);
		m_tray.Create( 1000, 10000 );
		m_tray.SetImage( &image, 1 );
		m_tray.Show( true );
		m_tray.SetTipInfo( _T("��ʾTab") );
		m_tray.ShowBalloonTip( _T(""), _T("�ѵ�¼"), 10000 );
	}
	m_tab.ClickItem( ID_LIST );
	SetWindowText( _T("RList") );
	SetStyle( GetStyle()|WS_CAPTION );
	m_MenuBk.hImage = CreateImage( XT2W( _T(".\\image\\menu_bk.png") ) );
	m_MenuBk.margin.left = 25;
	m_MenuBk.margin.bottom = m_MenuBk.margin.right = 10;
	m_MenuBk.margin.top = 15;
	m_menuSeparator.imageAvgClr = Color( 254, 150, 150, 150 ).GetValue();
	MENUATTRIBUTE menuAttrib;
	{
		Margin margin = { 3, 15, 6, 5 };
		menuAttrib.uMask = MA_MARGIN|MA_BKGND|MA_SEPARATOR|MA_SUBARROW|MA_DRAWMASK;
		menuAttrib.uDrawMask = MDM_SEPARATOR_FULLITEM;
		menuAttrib.pBkGnd  = &m_MenuBk;
		menuAttrib.pMargin	= &margin;
		menuAttrib.pSeparator = &m_menuSeparator;
		menuAttrib.pSubArrow = CreateImage( _T(".\\image\\lan_xl_1.png") );
		::UISetMenuAttribute( &menuAttrib );
	}
	return TRUE;  // ���������˿ؼ��Ľ��㣬���򷵻� TRUE
}

BOOL CRListDlg::_LoadImages()
{
	tstring strImagePath = _T(".\\image\\");
	{
		m_RLBmpArray[BMP_PHONE_NORMAL] = CreateImage( XT2W(strImagePath + _T("phone_1.png")) );
	}

	{
		m_RLBmpArray[BMP_PHONE_HOT] = CreateImage( XT2W(strImagePath + _T("phone_2.png")) );
	}
	{
		m_RLBmpArray[BMP_PHONE_PRESSED] = CreateImage( XT2W(strImagePath + _T("phone_3.png")) );
	}
	{
		m_RLBmpArray[BMP_SMS_NORMAL] = CreateImage(XT2W(strImagePath + _T("sms_1.png")) );
	}
	{
		m_RLBmpArray[BMP_SMS_HOT] = CreateImage(XT2W(strImagePath + _T("sms_2.png")) );
	}
	{
		m_RLBmpArray[BMP_SMS_PRESSED] = CreateImage(XT2W(strImagePath + _T("sms_3.png")) );
	}
	{
		m_RLBmpArray[BMP_SEND] = CreateImage(XT2W(strImagePath + _T("out.png")) );
	}
	{
		m_RLBmpArray[BMP_RECIEVED] = CreateImage(XT2W(strImagePath + _T("in.png")) );
	}
	{
		m_RLBmpArray[BMP_ROWHOT] = CreateImage(XT2W(strImagePath + _T("rbk_hot.png")) );
	}
	{
		m_RLBmpArray[BMP_ROWSEL] = CreateImage(XT2W(strImagePath + _T("rbk_sel.png")) );
	}
	m_RLBmpArray[BMP_OFFLINE] = CreateImage( XT2W(strImagePath + _T("lan_avatar_bg_2.png")) );
	{
		m_RLBmpArray[BMP_ONLINE] = CreateImage( XT2W(strImagePath + _T("head.png")) );
	}
	m_RLBmpArray[BMP_L3] = CreateImage( XT2W(strImagePath + _T("smsqp_l_03.png")) );
	m_RLBmpArray[BMP_L2] = CreateImage( XT2W(strImagePath + _T("smsqp_l_02.png")) );
	m_RLBmpArray[BMP_L1] = CreateImage( XT2W(strImagePath + _T("smsqp_l_01.png")) );
	m_RLBmpArray[BMP_R1] = CreateImage( XT2W(strImagePath + _T("smsqp_r_01.png")) );
	m_RLBmpArray[BMP_R2] = CreateImage( XT2W(strImagePath + _T("smsqp_r_02.png")) );
	m_RLBmpArray[BMP_R3] = CreateImage( XT2W(strImagePath + _T("smsqp_r_03.png")) );
	m_RLBmpArray[BMP_CAR] = CreateImage(_T(".\\image\\car.png") );
	m_RLBmpArray[BMP_PAD] = CreateImage(_T(".\\image\\pad.png") );
	HICON hIcon = m_RLBmpArray[BMP_ONLINE]->GetIcon();
	SetIcon( hIcon, TRUE );
	SetIcon( hIcon, FALSE );
	return TRUE;
}
enum
{
	IDC_ATC_HEAD = 1000,
	IDC_ATC_NAME,
	IDC_ATC_CALL,
	IDC_ATC_SMS,
	IDC_ATC_CONTENT,
	IDC_ATC_SIGN,
};

BOOL CRListDlg::_TranslateFromReocord( LPVOID pRecord, CUIListCtrl::ROW& rowData )
{
#define LINE_SPACE	  2
#define V_SPACE       7
#define H_SPACE       2
#define TEXT_HEIGHT   16
#define BUTTON_WIDTH  20
#define BUTTON_HEIGHT 20
#define HEAD_HEIGHT   32
#define IMAGE_HEIGHT  16

	INFO* pRecordInfo = (INFO*)pRecord;
	if ( NULL == pRecordInfo )
	{
		return FALSE;
	}
	//ƴװ�б�����
	int _X = H_SPACE;
	int _Y = V_SPACE;
	int _Xb = 0;
	int _Yb = 0;

	int nRowHeight = 48;
	int nYOrg = (nRowHeight - HEAD_HEIGHT)/2;
	int nXOrg = 5;
	//����ͷ��
	CUIImage* pUHead = NULL;
	if ( pUHead = (CUIImage*)rowData.GetXCtrl( IDC_ATC_HEAD ) )
	{
		pUHead->SetImage( m_RLBmpArray[BMP_ONLINE] );
	}
	else
	{
		pUHead = (CUIImage*)rowData.AddXCtrl( XW_IMAGE, _T(""), RECT_C( nXOrg, nYOrg, nXOrg + HEAD_HEIGHT, nYOrg + HEAD_HEIGHT ), IDC_ATC_HEAD );
		if ( pUHead )
		{
			pUHead->SetImage( m_RLBmpArray[BMP_ONLINE] );
		}
	}
	_X += 41;
	//�����ǳƣ���û���ǳ�ʱ����ʾ�ʺţ�
	IUICtrl* pUnitName = NULL;
	if ( pUnitName = rowData.GetXCtrl( IDC_ATC_NAME ) )
	{
		pUnitName->SetText( pRecordInfo->strSendName );
	}
	else
	{
		pUnitName = rowData.AddXCtrl( XW_TEXT, pRecordInfo->strSendName, RECT_C( _X, _Y, _X + 200, _Y+TEXT_HEIGHT ), IDC_ATC_NAME );
		if ( pUnitName )
		{
			pUnitName->SetTextColor( RGB(0,0,0) );
			pUnitName->SetFont( m_normalFont );
			pUnitName->SetStyle( pUnitName->GetStyle() | XWS_SINGLELINE | XWS_ENDELLIPSE );
		}
	}
	_Xb = _X;

	//��ʱ�������ֱ�ʶ
	//if ( 0 )
	//{
	//	//�����绰��ť
	//	CUIImage* pUnitClock = (CUIImage*)rowData.AddXCtrl( XW_IMAGE, _T(""), RECT_C( _X+nNameUnitWidth+H_SPACE, _Y, _X+nNameUnitWidth+BUTTON_WIDTH+H_SPACE, _Y+BUTTON_HEIGHT ) );
	//	if ( pUnitClock )
	//	{
	//		pUnitClock->SetImage( m_RLBmpArray[BMP_CLOCK] );
	//		pUnitClock->SetHotImage( m_RLBmpArray[BMP_CLOCKHOT] );
	//	}
	//}
	_X += 200 + H_SPACE;
	_Y -= 3;
	//�����绰��ť
	CUIButton* pButton = NULL;
	if ( pButton = (CUIButton*)rowData.GetXCtrl( IDC_ATC_CALL ) )
	{
		pButton->SetNormalImage( m_RLBmpArray[BMP_PHONE_NORMAL] );
		pButton->SetMouseOverImage( m_RLBmpArray[BMP_PHONE_HOT] );
		pButton->SetPressedImage( m_RLBmpArray[BMP_PHONE_PRESSED] );
	}
	else
	{
		pButton = (CUIButton*)rowData.AddXCtrl( XW_BUTTON, _T(""), RECT_C( _X, _Y, _X+BUTTON_WIDTH, _Y+BUTTON_HEIGHT ), IDC_ATC_CALL );
		if ( pButton )
		{
			pButton->SetNormalImage( m_RLBmpArray[BMP_PHONE_NORMAL] );
			pButton->SetMouseOverImage( m_RLBmpArray[BMP_PHONE_HOT] );
			pButton->SetPressedImage( m_RLBmpArray[BMP_PHONE_PRESSED] );
			pButton->SetStyle(XWS_HOTSHOW);
		}
	}

	_X += BUTTON_WIDTH + H_SPACE;
	//���뷢���Ű�ť
	pButton = NULL;
	if ( pButton = (CUIButton*)rowData.GetXCtrl( IDC_ATC_SMS ) )
	{
		pButton->SetNormalImage( m_RLBmpArray[BMP_SMS_NORMAL] );
		pButton->SetMouseOverImage( m_RLBmpArray[BMP_SMS_HOT] );
		pButton->SetPressedImage( m_RLBmpArray[BMP_SMS_PRESSED] );
	}
	else
	{
		pButton = (CUIButton*)rowData.AddXCtrl( XW_BUTTON, _T(""), RECT_C( _X, _Y, _X+BUTTON_WIDTH, _Y+BUTTON_HEIGHT ), IDC_ATC_SMS );
		if ( pButton )
		{
			pButton->SetNormalImage( m_RLBmpArray[BMP_SMS_NORMAL] );
			pButton->SetMouseOverImage( m_RLBmpArray[BMP_SMS_HOT] );
			pButton->SetPressedImage( m_RLBmpArray[BMP_SMS_PRESSED] );
			pButton->SetStyle(XWS_HOTSHOW);
		}
	}

	_X += BUTTON_WIDTH + H_SPACE;
	//���뷢���Ű�ť
	pButton = NULL;
	if ( pButton = (CUIButton*)rowData.GetXCtrl( IDC_ATC_SMS+200 ) )
	{
		pButton->SetNormalImage( m_RLBmpArray[BMP_SMS_NORMAL] );
		pButton->SetMouseOverImage( m_RLBmpArray[BMP_SMS_HOT] );
		pButton->SetPressedImage( m_RLBmpArray[BMP_SMS_PRESSED] );
	}
	else
	{
		pButton = (CUIButton*)rowData.AddXCtrl( XW_BUTTON, _T(""), RECT_C( _X, _Y, _X+BUTTON_WIDTH, _Y+BUTTON_HEIGHT ), IDC_ATC_SMS+200 );
		if ( pButton )
		{
			pButton->SetNormalImage( m_RLBmpArray[BMP_SMS_NORMAL] );
			pButton->SetMouseOverImage( m_RLBmpArray[BMP_SMS_HOT] );
			pButton->SetPressedImage( m_RLBmpArray[BMP_SMS_PRESSED] );
			pButton->SetStyle(XWS_HOTSHOW);
		}
	}

	_X += BUTTON_WIDTH + H_SPACE;
	//���뷢���Ű�ť
	pButton = NULL;
	if ( pButton = (CUIButton*)rowData.GetXCtrl( IDC_ATC_SMS+100 ) )
	{
		pButton->SetNormalImage( m_RLBmpArray[BMP_SMS_NORMAL] );
		pButton->SetMouseOverImage( m_RLBmpArray[BMP_SMS_HOT] );
		pButton->SetPressedImage( m_RLBmpArray[BMP_SMS_PRESSED] );
	}
	else
	{
		pButton = (CUIButton*)rowData.AddXCtrl( XW_BUTTON, _T(""), RECT_C( _X, _Y, _X+BUTTON_WIDTH, _Y+BUTTON_HEIGHT ), IDC_ATC_SMS+100 );
		if ( pButton )
		{
			pButton->SetNormalImage( m_RLBmpArray[BMP_SMS_NORMAL] );
			pButton->SetMouseOverImage( m_RLBmpArray[BMP_SMS_HOT] );
			pButton->SetPressedImage( m_RLBmpArray[BMP_SMS_PRESSED] );
			pButton->SetStyle(XWS_HOTSHOW);
		}
	}

	_X = _Xb;
	_Y += TEXT_HEIGHT + LINE_SPACE + 3;
	_X += H_SPACE;


	//����������ͱ�ʶ(ͼƬ)
	CUIImage* pUSign = NULL;
	if ( pUSign = (CUIImage*)rowData.GetXCtrl( IDC_ATC_SIGN ) )
	{
		pUSign->SetImage( m_RLBmpArray[BMP_RECIEVED] );
	}
	else
	{
		pUSign = (CUIImage*)rowData.AddXCtrl( XW_IMAGE, _T(""), RECT_C( _X, _Y, _X + IMAGE_HEIGHT, _Y+IMAGE_HEIGHT ), IDC_ATC_SIGN );
		if ( pUSign )
		{	
			//��������/���ն��ű�ʶ��������
			pUSign->SetImage( m_RLBmpArray[BMP_RECIEVED] );
		}
	}

	//�����������
	_Y+=2;
// 	static int test = 20;
// 	_Y+= test+20;
// 	test = -test;
	_X += IMAGE_HEIGHT + H_SPACE;
	//�����������
	IUICtrl* pUnitContent = NULL;
	if ( pUnitContent = rowData.GetXCtrl( IDC_ATC_CONTENT ) )
	{
		pUnitContent->SetText( pRecordInfo->strContent );
	}
	else
	{
		pUnitContent = rowData.AddXCtrl( XW_TEXT, pRecordInfo->strContent, RECT_C( _X, _Y, _X + 122, _Y+TEXT_HEIGHT ) , IDC_ATC_CONTENT );

		if( pUnitContent )
		{
			pUnitContent->SetFont( m_normalFont );
			pUnitContent->SetStyle( pUnitContent->GetStyle() | XWS_SINGLELINE | XWS_ENDELLIPSE );
			if ( 0 == pRecordInfo->strReadFlg.compare( _T("1")) )
			{
				pUnitContent->SetTextColor( RGB(0,0,0) );
			}
			//��δ�����ţ����
			else
			{
				pUnitContent->SetTextColor( RGB(0,0,0) );
			}
		}
	}

	return TRUE;
}

BOOL CRListDlg::_TranslateFromReocord1( LPVOID pRecord, CUIListCtrl::ROW& rowData )
{
#define LINE_SPACE	  2
#define V_SPACE       7
#define H_SPACE       2
#define TEXT_HEIGHT   16
#define BUTTON_WIDTH  20
#define BUTTON_HEIGHT 20
#define HEAD_HEIGHT   32
#define IMAGE_HEIGHT  16

	INFO* pRecordInfo = (INFO*)pRecord;
	if ( NULL == pRecordInfo )
	{
		return FALSE;
	}
	//ƴװ�б�����
	int _X = H_SPACE;
	int _Y = V_SPACE;
	int _Xb = 0;
	int _Yb = 0;

	int nRowHeight = 48;
	int nYOrg = (nRowHeight - HEAD_HEIGHT)/2;
	int nXOrg = 5;

	RECT rcClient ={ 0, 0, 300, 200 };
	//�����������
	rcClient.right -= 45;
	
	_X += 15;
	IUICtrl* pUnit = rowData.AddXCtrl( XW_TEXT, pRecordInfo->strTime, RECT_C( _X, _Y, RECT_W(rcClient), _Y+20 ), IDC_ATC_SIGN );
	pUnit->SetTextColor( RGB(0,0,0) );
	pUnit->SetStyle( XWS_SINGLELINE );
	pUnit->SetFont( m_normalFont );
	SIZE size = IUICtrl::TestTextSize( *pUnit );
	if ( pRecordInfo->bRecieved )
	{
		pUnit->SetRect( RECT_C(_X, _Y, _X+size.cx, _Y+size.cy) );
	}
	else
	{
		pUnit->SetRect( RECT_C(rcClient.right-size.cx, _Y, rcClient.right, _Y+size.cy) );
	}
	_Y += size.cy+10;
	
	pUnit = rowData.AddXCtrl( XW_BUTTON, _T(""), RECT_C( _X, _Y, RECT_W(rcClient), _Y+20 ), IDC_ATC_NAME );
	if ( pRecordInfo->bRecieved )
	{
		((CUIButton*)pUnit)->SetNormalImage( m_RLBmpArray[BMP_L1] );
		((CUIButton*)pUnit)->SetMouseOverImage( m_RLBmpArray[BMP_L2] );
		((CUIButton*)pUnit)->SetPressedImage( m_RLBmpArray[BMP_L3] );
	}
	else
	{
		((CUIButton*)pUnit)->SetNormalImage( m_RLBmpArray[BMP_R1] );
		((CUIButton*)pUnit)->SetMouseOverImage( m_RLBmpArray[BMP_R2] );
		((CUIButton*)pUnit)->SetPressedImage( m_RLBmpArray[BMP_R3] );
	}
	
	Margin margin;
	margin.left = 13;
	margin.top = 20;
	margin.right = 10;
	margin.bottom = 10;
	((CUIButton*)pUnit)->SetMargin( margin );

	IUICtrl* pUnitContent = NULL;
// 	if ( pUnitContent = rowData.GetXCtrl( IDC_ATC_CONTENT ) )
// 	{
// 		if ( pRecordInfo->bRecieved )
// 		{
// 			rcClient.right -= 50;
// 		}
// 		else
// 		{
// 			_X += 50;
// 			rcClient.left += 50;
// 		}
// 		pUnitContent->SetText( pRecordInfo->strContent );
// 		SIZE size = IUICtrl::TestTextSize( *pUnitContent );
// 		RECT rcText(_X, _Y, _X+size.cx, _Y+size.cy);
// 		pUnitContent->SetRect( rcText );
// 		rcText.InflateRect( 20, 10 );
// 		pUnit->SetRect( rcText );
// 	}
// 	else
// 	{
		if ( pRecordInfo->bRecieved )
		{
			rcClient.right -= 50;
		}
		else
		{
			_X += 50;
			rcClient.left += 50;
		}
		
		pUnitContent = rowData.AddXCtrl( XW_TEXT, pRecordInfo->strContent, RECT_C( _X, _Y, _X + RECT_W(rcClient), _Y+TEXT_HEIGHT ) , IDC_ATC_CONTENT );
		if( pUnitContent )
		{
			pUnitContent->SetFont( m_normalFont );
			pUnitContent->HasNotify( false );
			pUnitContent->SetStyle( pUnitContent->GetStyle() );
			SIZE size = IUICtrl::TestTextSize( *pUnitContent );
			if ( RECT_W(rcClient) > size.cy 
				&& !pRecordInfo->bRecieved )
			{
				_X = rcClient.right - size.cx;
			}
			RECT rcText={_X, _Y, _X+size.cx, _Y+size.cy};
			pUnitContent->SetRect( rcText );
			InflateRect( &rcText, 20, 10 );
			pUnit->SetRect( rcText );
			if ( 0 == pRecordInfo->strReadFlg.compare( _T("1")) ) 
			{
				pUnitContent->SetTextColor( RGB(0,0,0) );
			}
			//��δ�����ţ����
			else
			{
				pUnitContent->SetTextColor( RGB(0,0,0) );
			}
		}
	//}

	return TRUE;
}

void CRListDlg::XMessageReciever( UINT message, WPARAM wParam, LPARAM lParam, DWORD dwData )
{
	NM_PARAM* param = (NM_PARAM*)lParam;
	CRListDlg* pThis = (CRListDlg*)(DWORD_PTR)dwData;
	if ( param && pThis )
	{
		if ( XWM_DATACHANGE == message )
		{
			if ( IDC_ALPHA == param->nCtrlId )
			{
				if( param->wParam )
				{
					pThis->EnableBlurWindow( true );
				}
				else
				{
					pThis->EnableBlurWindow( false );
				}
			}
			else if ( IDC_SHOWTAB == param->nCtrlId )
			{
				RECT rcClient;
				pThis->GetClient( &rcClient );
				::InflateRect( &rcClient, -2, -2 );
 				if ( param->wParam != 0 )
 				{
 					rcClient.top = 82;
 				}
 				else
 				{
					rcClient.top = 52;
				}
				rcClient.bottom -= 10;
				pThis->m_vlist.SetRect( rcClient);
				pThis->m_list.SetRect( rcClient);
				pThis->m_autolist.SetRect( rcClient );
				pThis->m_tree.SetRect( rcClient );
				pThis->m_tab.Show( param->wParam != 0 );
				

				pThis->InvalidRect(NULL);
			}
			return;
		}
		
		if ( XLAY_SIZECHANGED == message )
		{
			CUILayPanel* pPanel = (CUILayPanel*)lParam;
			if( pPanel )
			{
				if ( wParam == 1008 )
				{
					IUICtrl* pCtrl = pPanel->GetXCtrl(ID_CLOSE);
					SIZE sizePanel = pPanel->GetSize();
					int _x = sizePanel.cx - 41;
					int _y = 1;
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C(_x, _y, _x+40, _y+20) );
					}
					pCtrl = pPanel->GetXCtrl(ID_MAX);
					if( pCtrl )
					{
						_x -= 41;
						pCtrl->SetRect( RECT_C(_x, _y, _x+40, _y+20) );
					}
					pCtrl = pPanel->GetXCtrl(ID_MINI);
					if( pCtrl )
					{
						_x -= 41;
						pCtrl->SetRect( RECT_C(_x, _y, _x+40, _y+20) );
					}
					pCtrl = pPanel->GetXCtrl(5050);
					RECT rcEdit= { 55, 25, 0, 45 };
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C(rcEdit.left, rcEdit.top, sizePanel.cx-202, rcEdit.bottom ) );
					}
					pCtrl = pPanel->GetXCtrl(ID_SKIN);
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C(sizePanel.cx-200, rcEdit.top, sizePanel.cx-118, rcEdit.bottom ) );
					}
					pCtrl = pPanel->GetXCtrl(IDC_ALPHA);
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C(sizePanel.cx-50, rcEdit.top+2, sizePanel.cx-8, rcEdit.bottom ) );
					}
					pCtrl = pPanel->GetXCtrl(IDC_SHOWTAB);
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C(sizePanel.cx-115, rcEdit.top+2, sizePanel.cx-52, rcEdit.bottom ) );
					}
				}
				else if ( wParam == 1010 )
				{
					IUICtrl* pCtrl = pPanel->GetXCtrl(ID_TREE);
					SIZE sizePanel = pPanel->GetSize();
					int _x = sizePanel.cx - 41;
					int _y = 1;
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C( 0, 0, sizePanel.cx, sizePanel.cy ) );
					}
					
					pCtrl = pPanel->GetXCtrl(ID_VLLIST);
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C( 0, 0, sizePanel.cx, sizePanel.cy ) );
					}

					pCtrl = pPanel->GetXCtrl(ID_LIST);
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C( 0, 0, sizePanel.cx, sizePanel.cy ) );
					}

					pCtrl = pPanel->GetXCtrl(ID_AUTOLIST);
					if( pCtrl )
					{
						pCtrl->SetRect( RECT_C( 0, 0, sizePanel.cx, sizePanel.cy ) );
					}
				}
			}
			return;
		}
		else if ( XLAY_LCLICK == message )
		{
			if( wParam == 1010 )
			{
				pThis->m_autolist.Show( ID_AUTOLIST == param->nCtrlId );
				pThis->m_list.Show( ID_LIST == param->nCtrlId );
				pThis->m_vlist.Show( ID_VLLIST == param->nCtrlId );
				pThis->m_tree.Show( ID_TREE == param->nCtrlId );
				pThis->InvalidRect( NULL );
			}
			return;
		}
		else if ( XLAY_RBDOWN == message )
		{
			POINT point = { GET_X_LPARAM(param->lParam), GET_Y_LPARAM(param->lParam)};
			if ( pThis->m_head.GetID() == wParam )
			{
				pThis->m_head.ClientToScreen( &point );
				CUIMenu menu;
				menu.InsertMenu( _T("���(&X)"), m_RLBmpArray[BMP_CAR], 1000 );
				menu.InsertMenu( _T("��С��(&N)"), m_RLBmpArray[BMP_PAD],1001 );
				menu.InsertMenu( _T("��ԭ(&R)"), m_RLBmpArray[BMP_PAD], 1003 );
				menu.InsertSpaceMenu();
				menu.InsertMenu( _T("�ر�(&C)"), m_RLBmpArray[BMP_PAD], 1002 );
				CUIMenu menu1;
				menu1.InsertMenu( _T("���(&X)"), HIMAGE(), 1000 );
				menu1.InsertMenu( _T("��С��(&N)"), HIMAGE(), 1001 );
				menu1.InsertMenu( _T("��ԭ(&R)"), HIMAGE(), 1003 );
				menu1.InsertSpaceMenu();
				menu1.InsertMenu( _T("�ر�(&C)"), HIMAGE(), 1002 );
				menu.InsertSubMenu( 1000, &menu1 );
				switch( menu.TrackPopupMenu( point.x-15, point.y, MAL_BOTTOM|MAL_RIGHT ) )
				{
				case 1002:
					{
						pThis->OnCancel();
					}
					break;
				case 1000:
					{
						if( !pThis->IsZoomed( ) )
						{
							pThis->ShowWindow( SW_SHOWMAXIMIZED );
						}
					}
					break;
				case 1001:
					{
						pThis->ShowWindow( SW_SHOWMINIMIZED );
					}
					break;
				case 1003:
					{
						pThis->ShowWindow( SW_RESTORE );
					}
					break;
				default:
					break;
				}
			}
			else if ( pThis->m_tree.GetID() == wParam )
			{
				CUITreeCtrl::HNODE hNode = pThis->m_tree.GetNodeFromPoint( point );
				pThis->m_tree.ClientToScreen( &point );
				CUIMenu menu;
				menu.InsertMenu( _T("ɾ��"), HIMAGE(), 1000 );
				if ( menu.TrackPopupMenu( point.x, point.y, 0 ) == 1000 )
				{
					pThis->m_tree.Remove( hNode );					
				}
			}
		}
		else if( XWM_LCLICK == message )
		{
			if( param->nCtrlId == ID_CLOSE )
			{
				pThis->OnCancel();
			}
			else if( param->nCtrlId == ID_MAX )
			{
				if( pThis->IsZoomed( ) )
				{
					pThis->ShowWindow( SW_RESTORE );
				}
				else
				{
					pThis->ShowWindow( SW_SHOWMAXIMIZED );
				}
			}
			else if( param->nCtrlId == ID_MINI )
			{
				pThis->ShowWindow( SW_SHOWMINIMIZED );
			}
			else if ( param->nCtrlId == ID_SKIN )
			{
				{
// 					CUIMenu menu;
// 					//menu.Create(  RECT_C( 200,200, 400, 800 ), 1000 );
// 					menu.TrackPopupMenu(  );
				}
				TCHAR szPath[MAX_PATH] = {0};
				GetCurrentDirectory( MAX_PATH, szPath );
				OPENFILENAME ofn;       // common dialog box structure
				TCHAR szFile[260]={0};       // buffer for file name

				// Initialize OPENFILENAME
				ZeroMemory(&ofn, sizeof(ofn));
				ofn.lStructSize = sizeof(ofn);
				ofn.hwndOwner = pThis->GetHandle();
				ofn.lpstrFile = szFile;
				//
				// Set lpstrFile[0] to '\0' so that GetOpenFileName does not 
				// use the contents of szFile to initialize itself.
				//
				ofn.lpstrFile[0] = _T('\0');
				ofn.nMaxFile = sizeof(szFile);
				ofn.lpstrFilter = _T("png\0*.png\0jpg\0*.jpg\0bmp\0*.bmp\0");
				ofn.nFilterIndex = 1;
				ofn.lpstrFileTitle = NULL;
				ofn.nMaxFileTitle = 0;
				ofn.lpstrInitialDir = NULL;
				ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

				// Display the Open dialog box. 

				if (GetOpenFileName(&ofn)) 
				{
					pThis->SetBkGnd(CreateImage( XT2W(ofn.lpstrFile)) );
				}
				SetCurrentDirectory( szPath );
			}
			return;
		}	
	}
}

void CRListDlg::InitHead()
{
	Margin margin;
	margin.left = margin.top=margin.right=margin.bottom= 3;
 	CUIImage image;
 	image.Create( _T(""), RECT_C( 5, 5, 45, 45 ) );
 	image.SetImage( m_RLBmpArray[BMP_ONLINE] );
 	image.SetMargin( margin );
 	image.HasNotify( false );
 	m_head.AddXCtrl( &image );

	CUIButton btn;
	btn.Create( _T(""), RECT_C( 0, 0, 50, 50 ),ID_HEAD );
	btn.SetMouseOverImage( m_RLBmpArray[BMP_OFFLINE] );
	m_head.AddXCtrl( &btn );
	CUIText name;
	name.Create( _T("��ã�"), RECT_C( 0, 0, 1, 1 ), ID_NAME );
	name.SetStyle( XWS_SINGLELINE );
	name.SetFont( m_normalFont );
	name.EnableOutGlaw(true);
	name.SetTextColor( RGB( 255,255,255 ) );
	SIZE size = IUICtrl::TestTextSize( name );
	name.SetRect(  RECT_C( 55, 2, 55+size.cx, 2+size.cy ) );
	m_head.AddXCtrl( &name );
	name.EnableOutGlaw(false);
	m_head.Show( true );
	m_head.SetBkGnd( X_TRANSPARENT );

	tstring strImagePath = _T(".\\image\\");
	HIMAGE hNormal = CreateImage( XT2W( strImagePath+_T("dl_btn_1.png") ) );
	HIMAGE hOver = CreateImage( XT2W( strImagePath+_T("dl_btn_2.png") ) ) ;
	HIMAGE hPressed = CreateImage( XT2W( strImagePath+_T("dl_btn_3.png") ) );
	CUIEdit edit;
	edit.Create( _T(""),RECT_C( 55,25, 500, 45 ), 5050 );
	edit.SetFont( m_normalFont );
	edit.SetMouseOverImage( CreateImage( XT2W( strImagePath+_T("editBk.png"))) );
	edit.SetFocusImage( edit.GetMouseOverImage() );
	margin.left = margin.right= 3;
	margin.top=margin.bottom= 2;
	edit.SetMargin( margin );
	edit.SetTextColor( RGB(255,255,255) );
	edit.SetText( _T("��Ҫ���Ҵ��ڵ����ɣ�") );
	edit.EnableOutGlaw( true );
	m_head.AddXCtrl( &edit );

	btn.SetRect( RECT_C( 0,0,40,20 ) );
	btn.SetNormalImage( CreateImage( XT2W( strImagePath+_T("c_n.png") ) ) );
	btn.SetMouseOverImage( CreateImage( XT2W( strImagePath+_T("c_h.png") ) ) );
	btn.SetPressedImage( CreateImage( XT2W( strImagePath+_T("c_p.png") ) ) );
	btn.SetID( ID_CLOSE );
	m_head.AddXCtrl( &btn );

	btn.SetNormalImage( CreateImage( XT2W( strImagePath+_T("mx_n.png") ) ) );
	btn.SetMouseOverImage( CreateImage( XT2W( strImagePath+_T("mx_h.png") ) ) );
	btn.SetPressedImage( CreateImage( XT2W( strImagePath+_T("mx_p.png") ) ) );
	btn.SetID( ID_MAX );
	m_head.AddXCtrl( &btn );

	btn.SetNormalImage( CreateImage( XT2W( strImagePath+_T("mm_n.png") ) ) );
	btn.SetMouseOverImage( CreateImage( XT2W( strImagePath+_T("mm_h.png") ) ) );
	btn.SetPressedImage( CreateImage( XT2W( strImagePath+_T("mm_p.png") ) ) );
	btn.SetID( ID_MINI );
	m_head.AddXCtrl( &btn );

	btn.SetNormalImage( hNormal );
	btn.SetMouseOverImage( hOver );
	btn.SetPressedImage( hPressed );
	btn.SetFont( m_normalFont );
	btn.SetStyle( XWS_SINGLELINE|XWS_ENDELLIPSE );
	btn.SetTextAlign( AL_CENTER );
	btn.SetRect( RECT_C( 10, 25, 92, 45 ) );
	btn.SetID( ID_SKIN );
	btn.SetText( _T("����") );
	m_head.AddXCtrl( &btn );

	CUICheckBox checkBox;
	checkBox.Create( _T("checkBox"), RECT_C( 300, 2, 360, 18 ), IDC_ATC_CHECKBOX );
	checkBox.SetFont( m_normalFont );
	{
		checkBox.SetNormalImage( CreateImage( ".\\image\\nec_uu_1.png" ), CreateImage( _T(".\\image\\nec_u_1.png") ) );
		checkBox.SetMouseOverImage( CreateImage( ".\\image\\nec_uu_2.png" ), CreateImage( ".\\image\\nec_u_2.png" ) );
		checkBox.SetTextColor( RGB(255,255,255) );
	}
	checkBox.SetID( IDC_ALPHA );
	checkBox.SetText( _T("͸��") );
	m_head.AddXCtrl( &checkBox );
	checkBox.SetID( IDC_SHOWTAB );
	checkBox.SetText( _T("��ʾTAB") );
	checkBox.SetCheck( true );
	m_head.AddXCtrl( &checkBox );
	//margin.left = margin.top=margin.right=margin.bottom= 10;
	//btn.SetMargin( margin );
	
	m_tab.SetNormalImage( hNormal );
	m_tab.SetMouseOverImage( hOver );
	m_tab.SetPressedImage( hPressed );
	CUIText text;
	text.Create( _T(""), RECT_C( 0, 0, 1, 1 ), -1 );
	text.SetFont( m_normalFont );
	text.SetStyle( XWS_SINGLELINE|XWS_ENDELLIPSE );
	text.SetTextAlign( AL_HCENTER|AL_VCENTER|AL_CENTER );
	text.SetRect( RECT_C( 0, 0, 82, 30 ) );
	text.SetID( ID_LIST );
	text.SetText( _T("�б��ؼ�") );
	text.HasNotify( false );
	CUITab::LPTABITEM pItem = m_tab.InsertItem( RECT_C( 10, 0, 92, 30 ), ID_LIST );
	pItem->AddXCtrl( &text );
	
	text.SetRect( RECT_C( 0, 0, 179-97, 30 ) );
	text.SetID( ID_AUTOLIST );
	text.SetText( _T("����Ӧ�б��ؼ�") );
	pItem = m_tab.InsertItem( RECT_C( 97, 0, 179, 30 ), ID_AUTOLIST );
	pItem->AddXCtrl( &text );

	text.SetRect( RECT_C( 0, 0, 266-184, 30 ) );
	text.SetID( ID_VLLIST);
	text.SetText( _T("�����б��ؼ�") );
	pItem = m_tab.InsertItem( RECT_C( 184, 0, 266, 30 ), ID_VLLIST );
	pItem->AddXCtrl( &text );

	text.SetRect( RECT_C( 0, 0, 353-271, 30 ) );
	text.SetID( ID_TREE );
	text.SetText( _T("���οؼ�") );
	pItem = m_tab.InsertItem( RECT_C( 271, 0, 353, 30 ), ID_TREE );
	pItem->AddXCtrl( &text );
	margin.left = margin.right = 10;
	margin.top = margin.bottom = 5;
	m_tab.SetItemMargin( margin );
	m_tab.EnableAutoMode( true );
	m_tab.Show(true);
}

void CRListDlg::InitTree()
{
	SetRedraw( FALSE );
	Margin margin;
	margin.left = margin.top=margin.right=margin.bottom= 3;
	m_tree.SetExpandAttrib( 3, 4 );
	CUITreeCtrl::NODEDATA row;
	CUITreeCtrl::HNODE hEnum;
	row.Show( true );
	CUITreeCtrl::HNODE hNode = NULL;
	for ( int _j = 0; _j < 100; _j++ )
	{
		INFO chatInfo;
		chatInfo.strContent = _T("SKSFDLKJ����ɫ�����Ե������ٶȷǷ����������ƶ��Ƕ�����������");
		chatInfo.strTime = _T("2010-10-01 19:20");
		chatInfo.strSendName = _T("������");
		chatInfo.strSendName += (char)(48+_j/100);
		chatInfo.strSendName += (char)(48+(_j%100)/10);
		chatInfo.strSendName += (char)(48+_j%10);
		chatInfo.strSendName += _T("1234567890");
		chatInfo.strRecvName = _T("������");
		chatInfo.strReadFlg = _T("1");
		chatInfo.bRecieved	= (_j%2 == 0);
		_TranslateFromReocord( (LPVOID)&chatInfo, row );
		row.SetMargin( 2 );
 		if ( NULL != hNode && _j%10 )
 		{
 			row.SetRect( RECT_C( 0,0,500,50 ) );
			row.SetData( _j );
			m_tree.Insert( row, NULL, hNode );
 		}
 		else
		{
			CUITreeCtrl::NODEDATA row;
			row.Show(true);
			CUIText text;
			tstring strName = _T("��ڵ�");
			strName += (char)(48+_j/100);
			text.Create( strName, RECT_C( 0,0,1,1 ),IDC_ATC_NAME );
			text.SetFont( m_normalFont );
			text.SetTextColor( RGB( 0,0,0 ) );
			text.HasNotify( false );
			text.SetStyle( XWS_SINGLELINE );
			SIZE size = IUICtrl::TestTextSize( text );
			text.SetRect( RECT_C( 24, 10, 24+size.cx, 10+size.cy ) );
			row.SetRect( RECT_C( 0, 0, 500, size.cy+20 ) );
			row.AddXCtrl( &text );
			CUIImage image;
			image.Create( _T(""), RECT_C(  10, (size.cy+15)/2, 19, (size.cy+15)/2+5  ), 3 );
			tstring strImagePath = _T(".\\image\\");
			image.SetImage( CreateImage( XT2W( strImagePath+_T("lan_xl_2.png") ) ) );
			row.AddXCtrl( &image );
			image.SetID( 4 );
			image.SetRect( RECT_C(  12, (size.cy+11)/2, 17, (size.cy+11)/2+9  ) );
			image.SetImage( CreateImage( XT2W( strImagePath+_T("lan_xl_1.png") ) ) );
			image.Show(false);
			row.AddXCtrl( &image );
			row.SetData( _j );
			hNode = m_tree.Insert( row, NULL, NULL );
			hNode->m_bExpand = true;
		}
	}
	hNode = m_tree.GetRoot();
	while( hNode )
	{
		m_tree.Enum( m_tree.GetFirstChild( hNode ), CRListDlg::EnumTree, 0 );
		hNode = m_tree.GetNextBrother( hNode );
		OutputDebugString( _T("\n��һ��:\n") );
	}
	SetRedraw( TRUE );
	InvalidateRect( GetHandle(), NULL, FALSE );
}