// UIWnd.cpp : ʵ���ļ�
#include <algorithm>
#include "UIPopMenu.h"
#include <CommCtrl.h>
#include <tchar.h>
#include <assert.h>
#include <WindowsX.h>
#include "UIdefine.h"
map<HWND, CUIPopMenu*> CUIPopMenu::m_mapWindows;
IMG*    CUIPopMenu::m_pBkGnd = NULL;
IMG*    CUIPopMenu::m_pBkItem = NULL;
IMG*    CUIPopMenu::m_pSeparator = NULL;
Margin  CUIPopMenu::m_margin = {0};
bool    CUIPopMenu::m_bLayered = false;
IImage*  CUIPopMenu::m_pSubArrow;//�Ӳ˵���ʶͼ��
UINT	CUIPopMenu::m_uItemHeight = 20;//�˵��߶�
UINT    CUIPopMenu::m_uIconWidth = 20; //�˵������ͼ�����
UINT    CUIPopMenu::m_uDrawMask  = MDM_ICON_MID;  //�˵���������� ��MENUDRAWMASK
UINT    CUIPopMenu::m_uAlpha = 255;     //�˵�͸����
HFONT   CUIPopMenu::m_font = NULL;
#define  ARROW_BORDER 5

void DrawImage( IImage* hImage, const RECT& rcDraw, const Margin& margin, HDC _hDC )
{
	if ( !hImage 
		|| !_hDC 
		|| RECT_ISEMPTY(rcDraw) )
	{
		return;
	}
	ImageInfo info = {0};
	hImage->GetImageInfo( &info );
	//topleft
	RECT rcTmp;
	RECT rcImg;
	RECT_S( rcTmp, rcDraw.left, rcDraw.top, rcDraw.left+margin.left,rcDraw.top+margin.top );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		rcImg = rcTmp;
		RECT_TO(rcImg, 0, 0 );
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}

	//topmidle
	RECT_S( rcTmp, rcDraw.left+margin.left, rcDraw.top, rcDraw.right-margin.right,rcDraw.top+margin.top );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		RECT_S( rcImg, margin.left, 0, info.Width-margin.right, margin.top );
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}

	//topright
	RECT_S( rcTmp, rcDraw.right-margin.right, rcDraw.top, rcDraw.right,rcDraw.top+margin.top );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		rcImg = rcTmp;
		RECT_TO(rcImg, info.Width-margin.right, 0 );
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}

	//midleleft
	RECT_S(rcTmp, rcDraw.left, rcDraw.top+margin.top, rcDraw.left+margin.left,rcDraw.bottom-margin.bottom );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		RECT_S(rcImg, 0, margin.top, margin.left, info.Height-margin.bottom );
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}

	//midleright
	RECT_S( rcTmp, rcDraw.right-margin.right, rcDraw.top + margin.top, rcDraw.right,rcDraw.bottom-margin.bottom );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		RECT_S(rcImg,info.Width - margin.right, margin.top, info.Width, info.Height-margin.bottom );
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}

	//midle
	RECT_S(rcTmp, rcDraw.left+margin.left, rcDraw.top + margin.top, rcDraw.right-margin.right,rcDraw.bottom-margin.bottom );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		int mr = margin.right;
		if( margin.right > 0 )
		{
			++mr;
		}
		int mb = margin.bottom;
		if( mb > 0 )
		{
			++mb;
		}
		RECT_S( rcImg, margin.left, margin.top, info.Width-mr, info.Height-mb);
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}

	//bottomleft
	RECT_S(rcTmp, rcDraw.left, rcDraw.bottom - margin.bottom, rcDraw.left+margin.left, rcDraw.bottom );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		RECT_S(rcImg, 0, info.Height-margin.bottom, margin.left, info.Height );
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}

	//bottommidle	
	RECT_S( rcTmp, rcDraw.left+margin.left, rcDraw.bottom - margin.bottom, rcDraw.right-margin.right,rcDraw.bottom );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		RECT_S( rcImg, margin.left, info.Height-margin.bottom, info.Width-margin.right, info.Height );
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}

	//bottomright
	RECT_S( rcTmp, rcDraw.right-margin.right, rcDraw.bottom - margin.bottom, rcDraw.right,rcDraw.bottom );
	if ( !RECT_ISEMPTY(rcTmp) )
	{
		RECT_S( rcImg, info.Width-margin.right, info.Height-margin.bottom, info.Width, info.Height );
		hImage->Draw( _hDC, &rcTmp, &rcImg );
	}
}
static CUIPopMenu* pTop = NULL;
// CUIPopMenu
CUIPopMenu::CUIPopMenu()
:m_nCmdRet(0)
,m_hBufferBmp(NULL)
,m_hOldBufferBmp( NULL )
,m_bPoping( FALSE )
,m_hWnd( NULL )
,m_subMenu(NULL)
,m_nMenuCount( 0 )
,m_pMenuData( NULL )
,m_pAccel(NULL)
,m_nAccelCount(0)
,m_fuFlags(0)
,m_nMouseIn(-1)
,m_nLbDown(-1)
,m_hbkBitmap(NULL)
,m_topOffset(0)
,m_hbkOldBitmap(NULL)
,m_parentMenu(NULL)
{
	if ( NULL == m_font )
	{
		LOGFONT lgFont;
		memset(&lgFont, 0, sizeof(LOGFONT));
		lgFont.lfHeight = -12;
		lstrcpy(lgFont.lfFaceName, _T("Arial"));
		lgFont.lfOutPrecision = OUT_TT_PRECIS;
		lgFont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
		lgFont.lfQuality = PROOF_QUALITY;
		lgFont.lfQuality = ANTIALIASED_QUALITY;
		lgFont.lfPitchAndFamily = FF_SWISS | VARIABLE_PITCH;
		lgFont.lfWeight = FW_NORMAL;
		m_font = CreateFontIndirect( &lgFont );
	}
	if ( pTop = NULL )
	{
		pTop = this;
	}
}

CUIPopMenu::~CUIPopMenu()
{
	if ( m_bufferDC )
	{
		if ( m_hBufferBmp )
		{
			SelectObject( m_bufferDC, m_hOldBufferBmp );
			DeleteObject( m_hBufferBmp );
			m_hOldBufferBmp = NULL;
		}
	}
	if ( m_font )
	{
		DeleteObject( m_font );
		m_font = NULL;
	}
	if ( pTop == this )
	{
		pTop = NULL;
	}
	if ( NULL == pTop )
	{
		DeleteObject( m_font );
	}
}

#define  SCREEN_BORDER 10
UINT CUIPopMenu::TrackPopupMenu( MENUDATA* pMenuData, int nCount, int x, int y, int fuFlags, ACCEL* pAccels /*= NULL*/, int nAccelCount /*= 0*/ )
{
	if ( NULL == pMenuData 
		|| nCount <= 0 )
	{
		return 0;
	}
	m_bPoping = TRUE;
	m_nCmdRet = 0;
	m_pAccel = pAccels;
	m_nAccelCount = nAccelCount;
	m_pMenuData = pMenuData;
	m_nMenuCount = nCount;
	m_fuFlags = fuFlags;
	SetFocus( NULL );
	if( !CreateMenu(  ) )
	{
		return m_nCmdRet;
	}

	RECT rcThis;
	GetWindowRect( m_hWnd, &rcThis );
	if ( fuFlags & MAL_LEFT )
	{
		RECT_TOX( rcThis, x-RECT_W(rcThis));
	}
	else 
	{
		RECT_TOX( rcThis, x);	
	}

	if ( fuFlags & MAL_TOP )
	{
		RECT_TOY( rcThis, y-RECT_H(rcThis) );
	}
	else
	{
		RECT_TOY( rcThis, y );
	}
	
	int nXScreen = GetSystemMetrics( SM_CXSCREEN );
	int nYScreen = GetSystemMetrics( SM_CYSCREEN );
	if ( rcThis.right > nXScreen - SCREEN_BORDER  )
	{
		RECT_TOX( rcThis, rcThis.left-RECT_W(rcThis) );
		if ( rcThis.left < SCREEN_BORDER )
		{
			RECT_TOX( rcThis, SCREEN_BORDER );
		}
	}
	else if ( rcThis.left < SCREEN_BORDER )
	{
		RECT_TOX( rcThis, x );
		if ( rcThis.right > nXScreen-SCREEN_BORDER )
		{
			RECT_TOX( rcThis, SCREEN_BORDER );
		}
	}
	if ( rcThis.bottom > nYScreen - SCREEN_BORDER )
	{
		RECT_TOY( rcThis, rcThis.top - RECT_H(rcThis) );
		if ( rcThis.top < SCREEN_BORDER )
		{
			RECT_TOY( rcThis, SCREEN_BORDER);
		}
	}
	else if ( rcThis.top < SCREEN_BORDER )
	{
		RECT_TOY( rcThis, y );
		if ( rcThis.bottom > nYScreen-SCREEN_BORDER )
		{
			RECT_TOY( rcThis, SCREEN_BORDER);
		}
	}

	//���ö��㴰��
	SetWindowPos(m_hWnd, HWND_TOPMOST, rcThis.left, rcThis.top, 0, 0, SWP_HIDEWINDOW|
		SWP_NOSIZE|SWP_NOACTIVATE);
	HACCEL hAccel = NULL;
	if ( m_pAccel )
	{
		hAccel = CreateAcceleratorTable( m_pAccel, m_nAccelCount );
	}
	ShowWindow( m_hWnd, SW_SHOW );
	if ( m_bLayered )
	{
		InvalidRect( NULL );
	}
	BOOL bIdle = TRUE;
	LONG lIdleCount = 0;
	MSG msg = {0};
	MSG msgLast = {0};
	MSG msgCur = {0};
	//for tracking the idle time state
	// acquire and dispatch messages until a WM_QUIT message is received.
	SetFocus( m_hWnd );
	while (m_bPoping)
	{
		// phase1: check to see if we can do idle work
		while (bIdle &&
			!::PeekMessage(&msg, NULL, NULL, NULL, PM_NOREMOVE))
		{
			// call OnIdle while in bIdle state
			if (!SendMessage( m_hWnd, 0x036A, MSGF_DIALOGBOX, lIdleCount++))
			{
				// stop idle processing next time
				bIdle = FALSE;
			}
		}
		// phase2: pump messages while available
		do
		{
			// pump message, but quit on WM_QUIT
			if (!::GetMessage( &msgCur, NULL, NULL, NULL))
			{
				// Note: prevents calling message loop things in 'ExitInstance'
				// will never be decremented
				m_bPoping = FALSE;
				break;
			}

			// process this message
			if ( msgCur.message != 0x036A
				&&( NULL == hAccel
				|| ( NULL != hAccel
				&& !::TranslateAccelerator( msgCur.hwnd, hAccel, &msgCur)))
				)
			{
				::TranslateMessage(&msgCur);
				::DispatchMessage(&msgCur);
			}
			// reset "no idle" state after pumping "normal" message
			//if (IsIdleMessage(&m_msgCur))
			// reset "no idle" state after pumping "normal" message
			if (msg.message == WM_MOUSEMOVE || msg.message == WM_NCMOUSEMOVE)
			{
				// mouse move at same position as last mouse move?
				if (msgLast.pt.x != msg.pt.x
					||msgLast.pt.y != msg.pt.y
					||msgCur.message != msg.message )
				{
					msgLast = msg;
					bIdle = TRUE;
					lIdleCount = 0;
				}
			}
			else if ( msg.message != WM_PAINT && msg.message != 0x0118 )
			{
				bIdle = TRUE;
				lIdleCount = 0;
			}

		} while (::PeekMessage(&msg, NULL, NULL, NULL, PM_NOREMOVE));
	}
	if ( hAccel )
	{
		DestroyAcceleratorTable( hAccel );
		hAccel = NULL;
	}
	if ( m_hWnd )
	{
		if ( m_mapWindows.size() )
		{
			m_mapWindows.erase( m_hWnd );
		}
		if (m_hWnd != NULL)
		{
			SetWindowPos(m_hWnd, NULL, 0, 0, 0, 0, SWP_HIDEWINDOW|
			SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_NOZORDER);
		}
		DestroyWindow( m_hWnd );
	}
	return m_nCmdRet;
}

BOOL CUIPopMenu::CreateMenu( HWND hParent )
{
	HWND hWnd = NULL;
	WNDCLASS wndcls;
	if (!(::GetClassInfo(NULL, _T("UI_MENU"), &wndcls)))//| CS_HREDRAW | CS_DROPSHADOW |CS_VREDRAW
	{
		// otherwise we need to register a new class
		wndcls.style            = CS_DBLCLKS  |  CS_SAVEBITS;
		wndcls.lpfnWndProc      = CUIPopMenu::WinProcess;
		wndcls.cbClsExtra       = wndcls.cbWndExtra = 0;
		wndcls.hInstance        = (HINSTANCE)::GetModuleHandle(NULL);
		wndcls.hIcon            = NULL;
		wndcls.hCursor          = LoadCursor( NULL, IDC_ARROW );
		wndcls.hbrBackground    = (HBRUSH)GetStockObject( WHITE_BRUSH );
		wndcls.lpszMenuName     = NULL;
		wndcls.lpszClassName    = _T("UI_MENU");
		RegisterClass(&wndcls);
	}
	
	m_hWnd = CreateWindowEx( WS_EX_TOOLWINDOW, _T("UI_MENU"), _T(""),  \
		WS_POPUP|WS_CLIPSIBLINGS|WS_CLIPCHILDREN, 0, 0, 0, 0, hParent, NULL,\
		(HINSTANCE)::GetModuleHandle(NULL), NULL );
	m_itemsRect.clear();
	if ( m_hWnd )
	{
		HDC hHelpDC = GetDC( m_hWnd );
		HFONT hOld = (HFONT)SelectObject( hHelpDC, m_font );
		RECT rectItem = { 0,0,1,1 };
		int nMaxWidth = 0;
		RectF rcItemF;
		m_topOffset = 0;
		//����ÿ���˵���ľ�������
		for ( int _i = 0; _i < m_nMenuCount; ++_i )
		{
			rectItem.top = 0;
			rectItem.bottom = 1;
			rectItem.left = 0;
			rectItem.right = 1;
			if( m_pMenuData[_i].nCmdId > 0 )
			{ 
				if ( m_pMenuData[_i].pszText[0] != 0 )
				{
					if ( m_bLayered )
					{
						Graphics graphics( m_hWnd );
						LOGFONT lf = {0};
						GetObject( m_font, sizeof( lf ), &lf );
						lf.lfHeight = abs(lf.lfHeight)+3;
						graphics.MeasureString( XT2W( m_pMenuData[_i].pszText ).c_str(), \
							-1, &Font( hHelpDC,&lf ), PointF(0.0,0.0), &rcItemF );
						rectItem.right = (LONG)rcItemF.Width;
						rectItem.bottom = (LONG)rcItemF.Height;
					}
					else
					{
						DrawText( hHelpDC, m_pMenuData[_i].pszText, (int)_tcslen(m_pMenuData[_i].pszText), &rectItem,\
							DT_VCENTER|DT_LEFT|DT_SINGLELINE|DT_CALCRECT );
					}
					if ( !m_topOffset )
					{
						m_topOffset = (m_uItemHeight-RECT_H(rectItem))>>1;
						if ( (m_uItemHeight-RECT_H(rectItem))%2 )
						{
							++m_topOffset;
						}
					}
				}
				rectItem.bottom = max((int)m_uItemHeight, RECT_H(rectItem));
			}
			else
			{
				if ( m_pSeparator )
				{
					if ( m_pSeparator->hImage )
					{
						ImageInfo info = {0};
						m_pSeparator->hImage->GetImageInfo( &info );
						rectItem.bottom = info.Height;
					}
					rectItem.bottom = 1;
				}
			}
			if ( RECT_W(rectItem) > nMaxWidth )
			{
				nMaxWidth = RECT_W(rectItem);
			}
			if ( m_itemsRect.size() )
			{
				RECT_TO( rectItem, m_itemsRect.back().left, m_itemsRect.back().bottom );
			}
			else
			{
				RECT_TO( rectItem, m_margin.left, m_margin.top );
			}
			m_itemsRect.push_back( rectItem );
		}
		int nSubArrow = 0;
		if ( m_pSubArrow )
		{
			ImageInfo info = {0};
			m_pSubArrow->GetImageInfo( &info );
			nSubArrow = info.Width+2*ARROW_BORDER;
		}
		for ( int _j = 0; _j < (int)m_itemsRect.size(); ++_j )
		{
			m_itemsRect.at( _j ).right = m_itemsRect.at( _j ).left+nMaxWidth+m_uIconWidth+nSubArrow;
		}
		::SelectObject( hHelpDC, hOld );
		ReleaseDC( m_hWnd, hHelpDC );
		rectItem = m_itemsRect.back();
		SetWindowPos( m_hWnd, NULL, 0, 0, m_itemsRect.back().right+m_margin.right, m_itemsRect.back().bottom+m_margin.bottom, SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOZORDER|SWP_HIDEWINDOW );
		m_mapWindows[m_hWnd] = this;
	}
	return m_hWnd != NULL;
}

void CUIPopMenu::DrawMenu( HDC hDC, LPCRECT lpRectClip /*= NULL*/ )
{
	RECT rcIcon = {0};
	Margin margin = {0};
	int nSubArrow = 0;
	if ( m_pSubArrow )
	{
		ImageInfo info = {0};
		m_pSubArrow->GetImageInfo( &info );
		nSubArrow = info.Width+2*ARROW_BORDER;
	}
	if ( m_bLayered )
	{
		Graphics graphics(hDC);
		graphics.Clear( Color::Black );
		graphics.SetSmoothingMode(SmoothingModeAntiAlias);
		graphics.SetInterpolationMode(InterpolationModeHighQualityBicubic);

		LOGFONT lf = {0};
		::GetObject( m_font, sizeof(LOGFONT), &lf );
		lf.lfHeight = abs(lf.lfHeight)+3;
		StringFormat strformat;
		SolidBrush brush(Color(254,0,0,0));
		RECT rect;
		DrawBkGnd( hDC );
		if ( m_nMouseIn >= 0
			&& m_pMenuData[m_nMouseIn].nCmdId > 0
			&& ::IntersectRect( &rect, lpRectClip, &m_itemsRect[m_nMouseIn] )
			&& !RECT_ISEMPTY(rect) )
		{
			if ( m_pBkItem )
			{
				if ( m_pBkItem->hImage )
				{
					DrawImage( m_pBkItem->hImage, m_itemsRect.at(m_nMouseIn), m_pBkItem->margin, hDC );
				}
				else
				{
					SolidBrush brushBk( m_pBkItem->imageAvgClr );
					graphics.FillRectangle( &brushBk, m_itemsRect.at(m_nMouseIn).left, m_itemsRect.at(m_nMouseIn).top, RECT_W(m_itemsRect.at(m_nMouseIn)), RECT_H(m_itemsRect.at(m_nMouseIn)) );
				}
			}
			else
			{
				SolidBrush brushBk( Color(255, 55, 140, 210) );
				graphics.FillRectangle( &brushBk, m_itemsRect.at(m_nMouseIn).left, m_itemsRect.at(m_nMouseIn).top, \
					RECT_W(m_itemsRect.at(m_nMouseIn)), RECT_H(m_itemsRect.at(m_nMouseIn)) );
			}
		}
		for ( int _i = 0; _i < m_nMenuCount; ++_i )
		{
			::IntersectRect( &rect, lpRectClip, &m_itemsRect[_i] );
			if( !RECT_ISEMPTY( rect ) )
			{ 
				if ( m_pMenuData[_i].nCmdId > 0 )
				{
					if ( m_pMenuData[_i].pImage )
					{
						ImageInfo info = {0};
						m_pMenuData[_i].pImage->GetImageInfo( &info );
						rcIcon.top = m_itemsRect[_i].top+((m_uItemHeight-info.Height)>>1);
						if ( (m_uItemHeight-info.Height)%2 )
						{
							++rcIcon.top;
						}
						if ( m_uDrawMask & MDM_ICON_LEFT )
						{
							rcIcon.left = m_itemsRect[_i].left;
						}
						else if ( m_uDrawMask & MDM_ICON_LEFT )
						{
							rcIcon.left = m_itemsRect[_i].right - info.Width;
						}
						else
						{
							rcIcon.left= m_itemsRect[_i].left+((m_uIconWidth-info.Width)>>1);
							if ( (m_uIconWidth-info.Width)%2 )
							{
								++rcIcon.left;
							}
						}
						rcIcon.right = rcIcon.left + info.Width;
						rcIcon.bottom = rcIcon.top + info.Height;
						DrawImage( m_pMenuData[_i].pImage, rcIcon, margin, hDC  );
					}
					if ( m_pMenuData[_i].pszText[0] != 0 )
					{
						HotkeyPrefix hotKeyFormat = m_uDrawMask&MDM_PREFIX_NONE?HotkeyPrefixNone:\
							m_uDrawMask&MDM_PREFIX_HIDE?HotkeyPrefixHide:HotkeyPrefixShow;
						strformat.SetHotkeyPrefix( hotKeyFormat );
						graphics.DrawString( XT2W( m_pMenuData[_i].pszText ).c_str(), -1, \
							&Font( hDC, &lf ), PointF((REAL)m_itemsRect[_i].left+m_uIconWidth,(REAL)m_itemsRect[_i].top+m_topOffset), &strformat, &brush );
					}
					if( m_pMenuData[_i].pSubMenu
						&& NULL != m_pSubArrow )
					{
						ImageInfo info = {0};
						m_pSubArrow->GetImageInfo( &info );
						rcIcon.left = m_itemsRect[_i].right-nSubArrow+ARROW_BORDER;
						rcIcon.top = m_itemsRect[_i].top+((m_uItemHeight-info.Height)>>1);
						rcIcon.right = rcIcon.left+info.Width;
						rcIcon.bottom  = rcIcon.top+info.Height;
						DrawImage( m_pSubArrow, rcIcon, margin, hDC );
					}
				}
				else
				{
					if ( m_pSeparator )
					{
						rect = m_itemsRect.at(_i);
						if ( !(m_uDrawMask & MDM_SEPARATOR_FULLITEM) )
						{
							rect.left += m_uIconWidth;
						}
						if ( m_pSeparator->hImage )
						{
							ImageInfo info = {0};
							m_pSeparator->hImage->GetImageInfo( &info );
							RECT rcSep = { 0, 0, info.Width, info.Height };
							m_pSeparator->hImage->Draw( hDC, &rect, &rcSep );
						}
						else if ( m_pSeparator->imageAvgClr != X_TRANSPARENT )
						{
							Pen line(Color(m_pSeparator->imageAvgClr));
							graphics.DrawLine( &line, Point(rect.left, rect.top), Point(rect.right, rect.top));
						}
					}
				}
			}
		}
	}
	else
	{
		RECT rect;
		GetClientRect( m_hWnd, &rect );
		DrawBkGnd( hDC );
		if ( m_nMouseIn >= 0
			&& m_pMenuData[m_nMouseIn].nCmdId > 0
			&& ::IntersectRect( &rect, lpRectClip, &m_itemsRect[m_nMouseIn] )
			&& !RECT_ISEMPTY(rect) )
		{
			Graphics graphics(hDC);
			if ( m_pBkItem )
			{
				if ( m_pBkItem->hImage )
				{
					DrawImage( m_pBkItem->hImage, m_itemsRect.at(m_nMouseIn), m_pBkItem->margin, hDC );
				}
				else
				{
					SolidBrush brushBk( m_pBkItem->imageAvgClr );
					graphics.FillRectangle( &brushBk, m_itemsRect.at(m_nMouseIn).left, m_itemsRect.at(m_nMouseIn).top, RECT_W(m_itemsRect.at(m_nMouseIn)), RECT_H(m_itemsRect.at(m_nMouseIn)) );
				}
			}
			else
			{
				SolidBrush brushBk( Color(255, 55, 140, 210) );
				graphics.FillRectangle( &brushBk, m_itemsRect.at(m_nMouseIn).left, m_itemsRect.at(m_nMouseIn).top, \
					RECT_W(m_itemsRect.at(m_nMouseIn)), RECT_H(m_itemsRect.at(m_nMouseIn)) );
			}
		}
		SetTextColor( hDC, RGB( 0, 0, 0 ) );
		SetBkMode( hDC, TRANSPARENT );
		HFONT hOld = (HFONT)SelectObject( hDC, m_font );
		for ( int _i = 0; _i < m_nMenuCount; ++_i )
		{
			if ( m_pMenuData[_i].pImage )
			{
				ImageInfo info = {0};
				m_pMenuData[_i].pImage->GetImageInfo( &info );
				rcIcon.top = m_itemsRect[_i].top+((m_uItemHeight-info.Height)>>1);
				if ( (m_uItemHeight-info.Height)%2 )
				{
					++rcIcon.top;
				}
				if ( m_uDrawMask & MDM_ICON_LEFT )
				{
					rcIcon.left = m_itemsRect[_i].left;
				}
				else if ( m_uDrawMask & MDM_ICON_LEFT )
				{
					rcIcon.left = m_itemsRect[_i].right - info.Width;
				}
				else
				{
					rcIcon.left= m_itemsRect[_i].left+((m_uIconWidth-info.Width)>>1);
					if ( (m_uIconWidth-info.Width)%2 )
					{
						++rcIcon.left;
					}
				}
				rcIcon.right = rcIcon.left + info.Width;
				rcIcon.bottom = rcIcon.top + info.Height;
				DrawImage( m_pMenuData[_i].pImage, rcIcon, margin, hDC  );
			}
			if( m_pMenuData[_i].nCmdId > 0 )
			{ 
				if ( m_pMenuData[_i].pszText[0] != 0 )
				{
					UINT nFormat = DT_VCENTER|DT_LEFT|DT_SINGLELINE|\
						(m_uDrawMask&MDM_PREFIX_NONE?DT_NOPREFIX:\
						m_uDrawMask&MDM_PREFIX_HIDE?DT_HIDEPREFIX:DT_PREFIXONLY);
					DrawText( hDC, m_pMenuData[_i].pszText, (int)_tcslen(m_pMenuData[_i].pszText),\
						&m_itemsRect.at(_i), nFormat );
				}
				if( m_pMenuData[_i].pSubMenu
					&& NULL != m_pSubArrow )
				{
					ImageInfo info = {0};
					m_pSubArrow->GetImageInfo( &info );
					rcIcon.left = m_itemsRect[_i].right -nSubArrow+ ARROW_BORDER;
					rcIcon.top = m_itemsRect[_i].top+((m_uItemHeight-info.Height)>>1);
					rcIcon.right = rcIcon.left+info.Width;
					rcIcon.bottom  = rcIcon.top+info.Height;
					DrawImage( m_pSubArrow, rcIcon, margin, hDC );
				}
			}
			else 
			{
				if ( m_pSeparator )
				{
					rect = m_itemsRect.at(_i);
					if ( !(m_uDrawMask & MDM_SEPARATOR_FULLITEM) )
					{
						rect.left += m_uIconWidth;
					}
					if ( m_pSeparator->hImage )
					{
						ImageInfo info = {0};
						m_pSeparator->hImage->GetImageInfo( &info );
						RECT rcSep = { 0, 0, info.Width, info.Height };
						m_pSeparator->hImage->Draw( hDC, &rect, &rcSep );
					}
					else if( m_pSeparator->imageAvgClr != X_TRANSPARENT )
					{
						Pen line(Color(m_pSeparator->imageAvgClr));
						Graphics graphics(hDC);
						graphics.DrawLine( &line, Point(rect.left, rect.top), Point(rect.right, rect.top));
					}
				}
			}
		}
		SelectObject( hDC, hOld );
	}
}

LRESULT WINAPI CUIPopMenu::WinProcess( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
	CUIPopMenu* pPop = CUIPopMenu::FromHandle( hWnd );
	if ( pPop )
	{
		return pPop->WinProc( message, wParam, lParam );
	}
	return DefWindowProc( hWnd, message, wParam, lParam );
}

LRESULT CUIPopMenu::WinProc( UINT message, WPARAM wParam, LPARAM lParam )
{
	switch( message )
	{
	case WM_ERASEBKGND:
		{
			return TRUE;
		}
		break;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hDC = ::BeginPaint( m_hWnd, &ps );
			if ( !m_bufferDC )
			{
				m_bufferDC.GetDC( hDC );
			}
			if ( hDC )
			{
				RECT rcClip;
				GetClipBox( hDC, &rcClip );
				if ( RECT_ISEMPTY( rcClip ) )
				{
					break;
				}
				if ( NULL == m_hBufferBmp )
				{
					RECT rcWnd;
					GetWindowRect( m_hWnd, &rcWnd );
					m_hBufferBmp = ::CreateCompatibleBitmap( hDC, RECT_W(rcWnd), RECT_H(rcWnd) );
					if ( m_hBufferBmp )
					{
						m_hOldBufferBmp = (HBITMAP)SelectObject( m_bufferDC, m_hBufferBmp );
					}
				}
				//���˵�
				DrawMenu( m_bufferDC, &rcClip );
				BitBlt( hDC, rcClip.left, rcClip.top, RECT_W(rcClip), RECT_H(rcClip),  m_bufferDC, rcClip.left, rcClip.top, SRCCOPY );
				::EndPaint( m_hWnd, &ps );
				return TRUE;
			}
		}
	case WM_MOUSEMOVE:
		{

			POINT point = { GET_X_LPARAM(lParam),GET_Y_LPARAM(lParam) };
			for ( int _i = 0; _i < (int)m_itemsRect.size(); ++_i )
			{
				if ( ::PtInRect( &m_itemsRect[_i], point ) 
					&& m_nMouseIn != _i )
				{
					int nPre = m_nMouseIn;
					m_nMouseIn = _i;
					if ( !m_bLayered )
					{
						RECT rcInvalidate = m_itemsRect[_i];
						if ( nPre >= 0 )
						{
							UnionRect( &rcInvalidate, &m_itemsRect[_i], &m_itemsRect[nPre] );
						}
						InvalidRect( &rcInvalidate );
						break;
					}
					InvalidRect( NULL );
					break;
				}
			}
			if ( m_bLayered )
			{
				RECT rcClient;
				GetClientRect( m_hWnd, &rcClient );
				if ( ::PtInRect( &rcClient, point ) )
				{
					if ( GetCapture() != m_hWnd )
					{
						SetCapture( m_hWnd );
					}
				}
				else
				{
					if ( GetCapture() == m_hWnd )
					{
						ReleaseCapture();
					}
					int nPre = m_nMouseIn;
					m_nMouseIn = -1;
					if( nPre >= 0 )
					{
						InvalidRect( NULL );
					}
				}
				break;
			}
			TRACKMOUSEEVENT tme;
			tme.cbSize = sizeof( tme );
			tme.hwndTrack = m_hWnd;
			tme.dwFlags = TME_LEAVE;
			tme.dwHoverTime = 2;
			_TrackMouseEvent( &tme );
		}
		break;
	case WM_SIZE:
		{
			if ( m_bufferDC )
			{
				if ( m_hBufferBmp )
				{
					::SelectObject( m_bufferDC, m_hOldBufferBmp );
					HDC hdc = GetDC( m_hWnd );
					if ( hdc )
					{
						RECT rcWnd;
						GetWindowRect( m_hWnd, &rcWnd );
						m_hBufferBmp = ::CreateCompatibleBitmap( hdc, RECT_W(rcWnd), RECT_H(rcWnd) );
						m_hOldBufferBmp = (HBITMAP)::SelectObject( m_bufferDC, m_hBufferBmp );
					}
					ReleaseDC( m_hWnd, hdc );
				}
			}
		}
		break;
	case WM_KEYDOWN:
		{
			if ( VK_UP == wParam )
			{
				--m_nMouseIn;
				if( m_nMouseIn < 0 )
				{
					m_nMouseIn = m_nMenuCount-1;
				}
				InvalidRect( NULL );
			}
			else if ( VK_DOWN == wParam
				|| VK_TAB == wParam )
			{
				++m_nMouseIn;
				if( m_nMouseIn > 0 )
				{
					m_nMouseIn %= m_nMenuCount; 
				}
				else
				{
					m_nMouseIn = 0;
				}
				InvalidRect( NULL );
			}
			else if ( VK_RIGHT == wParam )
			{
				if ( m_nMouseIn > 0 )
				{
					if ( m_pMenuData[m_nMouseIn].pSubMenu )
					{
						//CUIPopMenu* pMenu = 
					}
				}
			}
			else if ( VK_RETURN == wParam )
			{
				if ( m_nMouseIn >= 0 )
				{
					m_nCmdRet = m_pMenuData[m_nMouseIn].nCmdId;
				}
				else
				{
					m_nCmdRet = 0;
				}
				EndMenu();
			}
			else if ( VK_ESCAPE == wParam )
			{
				m_nCmdRet = 0;
				EndMenu();
			}
		}
		break;
	case WM_KEYUP:
		{

		}
		break;
	case WM_SYSKEYDOWN:
		{
			if ( VK_MENU == wParam )
			{
				EndMenu(); 
			}
		}
		break;
	case WM_LBUTTONDOWN:
		{
 			POINT point = { GET_X_LPARAM(lParam),GET_Y_LPARAM(lParam) };
			for ( int _i = 0; _i < (int)m_itemsRect.size(); ++_i )
			{
				if ( ::PtInRect( &m_itemsRect[_i], point ) )
				{
					m_nLbDown = _i;
					break;
				}
			}
		}
		break;
	case WM_LBUTTONUP:
		{
			POINT point = { GET_X_LPARAM(lParam),GET_Y_LPARAM(lParam) };
			for ( int _i = 0; _i < (int)m_itemsRect.size(); ++_i )
			{
				if ( ::PtInRect( &m_itemsRect[_i], point ) )
				{
					if( m_nLbDown >= 0
						&& m_pMenuData[_i].nCmdId > 0 )
					{
						m_nCmdRet = m_pMenuData[_i].nCmdId;
						EndMenu();
					}
					m_nLbDown = -1;
					break;
				}
			}
			m_nLbDown = -1;
		}
		break;
	case WM_MOUSELEAVE:
		{
			int nPre = m_nMouseIn;
			m_nMouseIn = -1;
			if ( nPre >= 0 )
			{
				if ( !m_bLayered )
				{
					InvalidRect( &m_itemsRect[nPre] );
					break;
				}
				InvalidRect( NULL );
			}
		}
		break;
	case WM_KILLFOCUS:
		{
 			if( m_subMenu
 				&& m_subMenu->IsSubMenuGetFocus( (HWND)wParam ))
 			{
 				return S_OK;
 			}
 			EndMenu();
		}
		break;
	default:
		break;
	}
	return DefWindowProc( m_hWnd, message, wParam, lParam );
}

void CUIPopMenu::InvalidRect( LPRECT lpRect )
{
	if ( !m_bLayered )
	{
		::InvalidateRect( m_hWnd, lpRect, FALSE );
	}
	else
	{
		BLENDFUNCTION blend;
		blend.BlendOp=0; //theonlyBlendOpdefinedinWindows2000
		blend.BlendFlags=0; //nothingelseisspecial...
		blend.AlphaFormat=1; //...
		blend.SourceConstantAlpha=m_uAlpha%256;//AC_SRC_ALPHA
		RECT rcThis;
		GetWindowRect( m_hWnd, &rcThis );
		POINT ptWinPos={rcThis.left,rcThis.top};
		::ScreenToClient( m_hWnd, (LPPOINT)&rcThis );
		::ScreenToClient( m_hWnd, ((LPPOINT)&rcThis)+1 );
		LPRECT lpClip = lpRect;
		if ( NULL == lpClip )
		{
			lpClip = &rcThis;
		}
		if ( !m_bufferDC )
		{
			HDC hdcThis = GetDC( m_hWnd );
			m_bufferDC.GetDC( hdcThis );
			RECT rcWnd;
			GetWindowRect( m_hWnd, &rcWnd );
			m_hBufferBmp = ::CreateCompatibleBitmap( hdcThis, RECT_W(rcWnd), RECT_H(rcWnd) );
			if ( m_hBufferBmp )
			{
				m_hOldBufferBmp = (HBITMAP)SelectObject( m_bufferDC, m_hBufferBmp );
			}
			ReleaseDC( m_hWnd, hdcThis );
		}
		
		DrawMenu( m_bufferDC, lpClip );
		HDC hdcScreen=::GetDC (m_hWnd);
		SIZE sizeWindow={RECT_W(rcThis),RECT_H(rcThis)};
		POINT ptSrc={0,0};
		DWORD dwExStyle=GetWindowLong(m_hWnd,GWL_EXSTYLE);
		if((dwExStyle&0x80000)!=0x80000)
			SetWindowLong(m_hWnd,GWL_EXSTYLE,dwExStyle^0x80000);
 		UpdateLayeredWindow( m_hWnd,hdcScreen,&ptWinPos,
 			&sizeWindow,m_bufferDC,&ptSrc,0,&blend,ULW_ALPHA);
		::ReleaseDC(m_hWnd,hdcScreen);
		hdcScreen=NULL;
	}
}

void CUIPopMenu::DrawBkGnd( HDC hdc )
{
	RECT rcThis;
	GetClientRect( m_hWnd, &rcThis );
	if ( m_pBkGnd )
	{
		if ( m_pBkGnd->hImage )
		{
			DrawImage( m_pBkGnd->hImage, rcThis, m_pBkGnd->margin, hdc );
		}
		else
		{
			Graphics graphics( hdc );
			SolidBrush brushBk( m_pBkGnd->imageAvgClr );
			graphics.FillRectangle( &brushBk, rcThis.left, rcThis.top, RECT_W(rcThis), RECT_H(rcThis) );
		}
	}
	else
	{
		Graphics graphics( hdc );
		SolidBrush brushBk( Color( 255, 255, 255, 255 ) );
		graphics.FillRectangle( &brushBk, rcThis.left, rcThis.top, RECT_W(rcThis), RECT_H(rcThis) );
	}
}

void CUIPopMenu::EndMenu()
{
	m_bPoping = FALSE;
	if (m_hWnd != NULL)
	{
		SetWindowPos(m_hWnd, NULL, 0, 0, 0, 0, SWP_HIDEWINDOW|
			SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_NOZORDER);
		if ( this != pTop )
		{
			delete this;
		}
	}
}